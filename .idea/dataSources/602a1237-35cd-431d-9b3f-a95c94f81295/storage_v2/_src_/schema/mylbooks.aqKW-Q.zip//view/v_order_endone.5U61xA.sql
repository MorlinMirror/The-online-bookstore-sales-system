create view v_order_endone as
select `mylbooks`.`t_order`.`order_id`    AS `order_id`,
       `mylbooks`.`t_order`.`order_time`  AS `order_time`,
       `mylbooks`.`t_order`.`user_id`     AS `user_id`,
       `mylbooks`.`t_user`.`user_name`    AS `user_name`,
       `mylbooks`.`t_order`.`order_total` AS `order_total`,
       `mylbooks`.`t_order`.`order_price` AS `order_price`
from (`mylbooks`.`t_order`
       join `mylbooks`.`t_user`)
where (`mylbooks`.`t_order`.`user_id` = `mylbooks`.`t_user`.`user_id`)
order by `mylbooks`.`t_order`.`order_id` desc
limit 0,1;

