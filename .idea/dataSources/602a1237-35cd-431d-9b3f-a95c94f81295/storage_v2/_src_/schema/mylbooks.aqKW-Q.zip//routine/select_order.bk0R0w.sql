create procedure select_order(IN data varchar(20), IN id varchar(20))
BEGIN
SELECT * FROM v_order WHERE order_time LIKE data AND user_id LIKE id ;
END;

