create procedure select_name(IN name varchar(20))
BEGIN
SELECT * FROM v_book WHERE book_name LIKE name OR book_author LIKE name OR book_pub LIKE name or book_outline LIKE name  or sort_name LIKE name;
END;

