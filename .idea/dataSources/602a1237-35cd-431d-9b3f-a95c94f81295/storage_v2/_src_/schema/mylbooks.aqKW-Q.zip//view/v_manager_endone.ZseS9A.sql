create view v_manager_endone as
select `mylbooks`.`t_manager`.`manager_id`    AS `manager_id`,
       `mylbooks`.`t_manager`.`manager_name`  AS `manager_name`,
       `mylbooks`.`t_manager`.`manager_phone` AS `manager_phone`,
       `mylbooks`.`t_manager`.`manager_pw`    AS `manager_pw`,
       `mylbooks`.`t_manager`.`manager_grade` AS `manager_grade`
from `mylbooks`.`t_manager`
order by `mylbooks`.`t_manager`.`manager_id` desc
limit 0,1;

