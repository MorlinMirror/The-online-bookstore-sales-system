create procedure select_name_copy(IN name varchar(20))
BEGIN
SELECT * FROM v_book WHERE book_isbn LIKE name ;
END;

