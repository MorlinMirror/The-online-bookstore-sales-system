create view v_book_endone as
select `mylbooks`.`t_book`.`book_id`        AS `book_id`,
       `mylbooks`.`t_book`.`book_isbn`      AS `book_isbn`,
       `mylbooks`.`t_book`.`book_name`      AS `book_name`,
       `mylbooks`.`t_book`.`book_author`    AS `book_author`,
       `mylbooks`.`t_book`.`book_pub`       AS `book_pub`,
       `mylbooks`.`t_book`.`book_num`       AS `book_num`,
       `mylbooks`.`t_book`.`book_price`     AS `book_price`,
       `mylbooks`.`t_book`.`book_image`     AS `book_image`,
       `mylbooks`.`t_book`.`sort_id`        AS `sort_id`,
       `mylbooks`.`t_book_sort`.`sort_name` AS `sort_name`,
       `mylbooks`.`t_book`.`book_time`      AS `book_time`,
       `mylbooks`.`t_book`.`book_outline`   AS `book_outline`
from `mylbooks`.`t_book`
       join `mylbooks`.`t_book_sort`
where (`mylbooks`.`t_book`.`sort_id` = `mylbooks`.`t_book_sort`.`sort_id`)
order by `mylbooks`.`t_book`.`book_id` desc
limit 0,1;

