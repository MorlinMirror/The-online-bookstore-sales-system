create view v_test as
select `mylbooks`.`t_cart`.`user_id`                                    AS `user_id`,
       `mylbooks`.`t_cart`.`book_id`                                    AS `book_id`,
       `mylbooks`.`t_cart`.`cart_num`                                   AS `cart_num`,
       (`mylbooks`.`t_cart`.`book_id` * `mylbooks`.`t_cart`.`cart_num`) AS `t_cart.book_id*t_cart.cart_num`,
       sum(`mylbooks`.`t_cart`.`cart_num`)                              AS `Sum(t_cart.cart_num)`
from `mylbooks`.`t_cart`
group by `mylbooks`.`t_cart`.`user_id`,`mylbooks`.`t_cart`.`book_id`,`mylbooks`.`t_cart`.`cart_num`;

