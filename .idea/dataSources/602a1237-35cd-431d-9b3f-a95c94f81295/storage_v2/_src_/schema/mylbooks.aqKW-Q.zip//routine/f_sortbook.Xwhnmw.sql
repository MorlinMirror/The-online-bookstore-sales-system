create procedure f_sortbook(IN id int)
BEGIN
	#Routine body goes here...
SELECT *FROM t_book WHERE sort_id = id;
	
END;

