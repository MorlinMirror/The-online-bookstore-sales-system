create view v_sort_endone as
select `mylbooks`.`t_book_sort`.`sort_id`   AS `sort_id`,
       `mylbooks`.`t_book_sort`.`sort_name` AS `sort_name`,
       `mylbooks`.`t_book_sort`.`sort_img`  AS `sort_img`
from `mylbooks`.`t_book_sort`
order by `mylbooks`.`t_book_sort`.`sort_id` desc
limit 0,1;

