create view v_cart as
select `mylbooks`.`t_cart`.`user_id`       AS `user_id`,
       `mylbooks`.`t_user`.`user_name`     AS `user_name`,
       `mylbooks`.`t_cart`.`book_id`       AS `book_id`,
       `mylbooks`.`t_book`.`book_name`     AS `book_name`,
       sum(`mylbooks`.`t_cart`.`cart_num`) AS `cart_count`,
       `mylbooks`.`t_book`.`book_price`    AS `book_price`
from ((`mylbooks`.`t_cart` join `mylbooks`.`t_book`)
       join `mylbooks`.`t_user`)
where ((`mylbooks`.`t_cart`.`book_id` = `mylbooks`.`t_book`.`book_id`) and
       (`mylbooks`.`t_user`.`user_id` = `mylbooks`.`t_cart`.`user_id`))
group by `mylbooks`.`t_cart`.`user_id`,`mylbooks`.`t_user`.`user_name`,`mylbooks`.`t_book`.`book_name`,`mylbooks`.`t_cart`.`book_id`
order by `mylbooks`.`t_cart`.`book_id`;

