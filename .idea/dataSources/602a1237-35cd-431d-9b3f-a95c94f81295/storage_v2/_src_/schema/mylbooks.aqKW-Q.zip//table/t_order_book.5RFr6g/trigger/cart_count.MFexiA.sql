create trigger cart_count
  after INSERT
  on t_order_book
  for each row
BEGIN
UPDATE t_book b, t_order_book o set b.book_num = b.book_num + o.cart_count
WHERE o.book_id = b.book_id;
END;

