create view v_order_book as
select `mylbooks`.`t_order_book`.`order_id`   AS `order_id`,
       `mylbooks`.`t_user`.`user_name`        AS `user_name`,
       `mylbooks`.`t_book`.`book_name`        AS `book_name`,
       `mylbooks`.`t_order_book`.`cart_count` AS `cart_count`,
       `mylbooks`.`t_book`.`book_price`       AS `book_price`,
       `mylbooks`.`t_order_book`.`cart_price` AS `cart_price`
from (((`mylbooks`.`t_order_book` join `mylbooks`.`t_book`) join `mylbooks`.`t_order`)
       join `mylbooks`.`t_user`)
where ((`mylbooks`.`t_order_book`.`book_id` = `mylbooks`.`t_book`.`book_id`) and
       (`mylbooks`.`t_order_book`.`order_id` = `mylbooks`.`t_order`.`order_id`) and
       (`mylbooks`.`t_order`.`user_id` = `mylbooks`.`t_user`.`user_id`))
order by `mylbooks`.`t_order_book`.`order_id`;

