create view v_user_endone as
select `mylbooks`.`t_user`.`user_id`    AS `user_id`,
       `mylbooks`.`t_user`.`user_name`  AS `user_name`,
       `mylbooks`.`t_user`.`user_sex`   AS `user_sex`,
       `mylbooks`.`t_user`.`user_birth` AS `user_birth`,
       `mylbooks`.`t_user`.`user_phone` AS `user_phone`,
       `mylbooks`.`t_user`.`user_email` AS `user_email`,
       `mylbooks`.`t_user`.`user_image` AS `user_image`,
       `mylbooks`.`t_user`.`user_pw`    AS `user_pw`
from `mylbooks`.`t_user`
order by `mylbooks`.`t_user`.`user_id` desc
limit 0,1;

